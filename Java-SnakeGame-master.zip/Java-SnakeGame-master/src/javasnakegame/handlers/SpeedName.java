
package javasnakegame.handlers;

public enum SpeedName {
    LOW,
    MEDIUM,
    HIGH
}
